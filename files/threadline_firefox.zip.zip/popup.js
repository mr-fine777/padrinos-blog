document.addEventListener('DOMContentLoaded', function() {
  const statusText = document.getElementById('statusText');
  const itemIdDiv = document.getElementById('itemId');
  const downloadBtn = document.getElementById('downloadBtn');
  const loading = document.getElementById('loading');
  const downloadText = document.getElementById('downloadText');
  const status = document.getElementById('status');

  // Check if we're on a Roblox catalog page
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    const currentTab = tabs[0];
    const url = currentTab.url;
    
    if (url && url.includes('roblox.com/catalog/')) {
      // Extract item ID from URL
      const itemId = extractItemId(url);
      
      if (itemId) {
        statusText.textContent = 'Template found!';
        itemIdDiv.textContent = `Item ID: ${itemId}`;
        itemIdDiv.style.display = 'block';
        downloadBtn.disabled = false;
        
        // Store item ID for download
        downloadBtn.dataset.itemId = itemId;
      } else {
        statusText.textContent = 'Could not find item ID in URL';
        status.className = 'status error';
      }
    } else {
      statusText.textContent = 'Please navigate to a Roblox catalog page';
      status.className = 'status error';
    }
  });

  // Handle download button click
  downloadBtn.addEventListener('click', function() {
    const itemId = this.dataset.itemId;
    
    if (!itemId) {
      showError('No item ID found');
      return;
    }

    // Show loading state
    downloadBtn.disabled = true;
    loading.classList.add('show');
    downloadText.style.display = 'none';
    statusText.textContent = 'Downloading template...';

    // Send message to background script to download
    chrome.runtime.sendMessage({
      action: 'downloadTemplate',
      itemId: itemId
    }, function(response) {
      if (response.success) {
        showSuccess('Template downloaded successfully!');
      } else {
        showError(response.error || 'Download failed');
      }
      
      // Reset button state
      downloadBtn.disabled = false;
      loading.classList.remove('show');
      downloadText.style.display = 'inline';
    });
  });

  function extractItemId(url) {
    // Match /catalog/123456789 or /catalog/123456789/anything
    const match = url.match(/\/catalog\/(\d+)/);
    return match ? match[1] : null;
  }

  function showError(message) {
    statusText.textContent = message;
    status.className = 'status error';
  }

  function showSuccess(message) {
    statusText.textContent = message;
    status.className = 'status success';
  }
}); 