// Background script to handle template downloads
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === 'downloadTemplate') {
    downloadTemplate(request.itemId)
      .then(function(result) {
        sendResponse({success: true, data: result});
      })
      .catch(function(error) {
        sendResponse({success: false, error: error.message});
      });
    
    // Return true to indicate we'll send a response asynchronously
    return true;
  }
});

async function downloadTemplate(itemId) {
  try {
    // Get template URL from API
    const apiUrl = `https://rbxdex.com/api/template/${itemId}`;
    const response = await fetch(apiUrl, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      throw new Error(`API request failed: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();

    if (!data.url || typeof data.url !== 'string' || !data.url.endsWith('.png')) {
      throw new Error('Template not found for this item. This may not be a shirt/pants, or the API is down.');
    }

    // Fetch template image
    let templateUrl = data.url.startsWith('/') ? 'https://rbxdex.com' + data.url : data.url;
    const templateResp = await fetch(templateUrl);
    if (!templateResp.ok) throw new Error('Failed to fetch template image.');
    const templateBlob = await templateResp.blob();

    // Fetch watermark image (assume watermark.png is in extension root)
    const watermarkUrl = chrome.runtime.getURL('watermark.png');
    const watermarkResp = await fetch(watermarkUrl);
    if (!watermarkResp.ok) throw new Error('Failed to fetch watermark image.');
    const watermarkBlob = await watermarkResp.blob();

    // Draw both images on canvas
    const templateImg = await blobToImage(templateBlob);
    const watermarkImg = await blobToImage(watermarkBlob);

    const canvas = new OffscreenCanvas(templateImg.width, templateImg.height);
    const ctx = canvas.getContext('2d');
    ctx.drawImage(templateImg, 0, 0);
    ctx.drawImage(watermarkImg, 0, 0, templateImg.width, templateImg.height); // scale watermark to fit

    const finalBlob = await canvas.convertToBlob();

    // Convert Blob to base64 data URL
    const finalUrl = await blobToDataUrl(finalBlob);
    const filename = `${itemId}_threadline.png`;

    const downloadId = await chrome.downloads.download({
      url: finalUrl,
      filename: filename,
      saveAs: false
    });

    return {
      downloadId: downloadId,
      filename: filename,
      url: finalUrl
    };

  } catch (error) {
    console.error('Download error:', error);
    throw new Error(error.message || 'Failed to download template.');
  }
}

// Helper to convert Blob to ImageBitmap
async function blobToImage(blob) {
  const bitmap = await createImageBitmap(blob);
  return bitmap;
}

// Add this helper function at the end of the file:
async function blobToDataUrl(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

// Handle download completion
chrome.downloads.onChanged.addListener(function(downloadDelta) {
  if (downloadDelta.state && downloadDelta.state.current === 'complete') {
    console.log('Download completed:', downloadDelta.id);
  } else if (downloadDelta.state && downloadDelta.state.current === 'interrupted') {
    console.error('Download interrupted:', downloadDelta.id);
  }
});