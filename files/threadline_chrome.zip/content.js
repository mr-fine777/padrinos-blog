// Content script that runs on Roblox catalog pages
(function() {
  'use strict';

  // Check if we're on a catalog page
  if (window.location.href.includes('roblox.com/catalog/')) {
    console.log('Roblox Template Downloader: Catalog page detected');
    
    // Extract item ID from URL
    const itemId = extractItemId(window.location.href);
    
    if (itemId) {
      console.log('Roblox Template Downloader: Item ID found:', itemId);
      
      // Optionally inject a download button into the page
      injectDownloadButton(itemId);
    }
  }

  function extractItemId(url) {
    // Match /catalog/123456789 or /catalog/123456789/anything
    const match = url.match(/\/catalog\/(\d+)/);
    return match ? match[1] : null;
  }

  function injectDownloadButton(itemId) {
    // Wait for the page to load
    setTimeout(() => {
      // Look for a good place to inject the button
      const targetSelectors = [
        '.item-details-container',
        '.item-details',
        '.item-info',
        '.item-header',
        '.item-title-container'
      ];

      let targetElement = null;
      
      for (const selector of targetSelectors) {
        targetElement = document.querySelector(selector);
        if (targetElement) break;
      }

      // If no specific container found, try to find a reasonable place
      if (!targetElement) {
        targetElement = document.querySelector('.item-details') || 
                       document.querySelector('.item-info') ||
                       document.querySelector('main') ||
                       document.body;
      }

      if (targetElement && !document.getElementById('roblox-template-downloader-btn')) {
        const downloadBtn = createDownloadButton(itemId);
        targetElement.appendChild(downloadBtn);
      }
    }, 2000); // Wait 2 seconds for page to load
  }

  function createDownloadButton(itemId) {
    const button = document.createElement('button');
    button.id = 'roblox-template-downloader-btn';
    button.innerHTML = '🎨 Download Template';
    button.style.cssText = `
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      border: none;
      padding: 10px 20px;
      border-radius: 5px;
      cursor: pointer;
      font-size: 14px;
      font-weight: bold;
      margin: 10px 0;
      transition: all 0.3s ease;
      box-shadow: 0 2px 4px rgba(0,0,0,0.2);
    `;

    button.addEventListener('mouseenter', function() {
      this.style.transform = 'translateY(-2px)';
      this.style.boxShadow = '0 4px 8px rgba(0,0,0,0.3)';
    });

    button.addEventListener('mouseleave', function() {
      this.style.transform = 'translateY(0)';
      this.style.boxShadow = '0 2px 4px rgba(0,0,0,0.2)';
    });

    button.addEventListener('click', function() {
      // Send message to background script to download
      chrome.runtime.sendMessage({
        action: 'downloadTemplate',
        itemId: itemId
      }, function(response) {
        if (response.success) {
          showNotification('Template downloaded successfully!', 'success');
        } else {
          showNotification('Download failed: ' + (response.error || 'Unknown error'), 'error');
        }
      });
    });

    return button;
  }

  function showNotification(message, type) {
    // Create notification element
    const notification = document.createElement('div');
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      padding: 15px 20px;
      border-radius: 5px;
      color: white;
      font-weight: bold;
      z-index: 10000;
      max-width: 300px;
      word-wrap: break-word;
      animation: slideIn 0.3s ease;
    `;

    if (type === 'success') {
      notification.style.background = '#4CAF50';
    } else {
      notification.style.background = '#f44336';
    }

    notification.textContent = message;

    // Add animation CSS
    const style = document.createElement('style');
    style.textContent = `
      @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
      }
    `;
    document.head.appendChild(style);

    document.body.appendChild(notification);

    // Remove notification after 3 seconds
    setTimeout(() => {
      if (notification.parentNode) {
        notification.parentNode.removeChild(notification);
      }
    }, 3000);
  }
})(); 