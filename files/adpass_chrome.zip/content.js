// Wrap everything in a self-executing function
(function() {
    try {
        // Add opt-out state variable
        let isOptedOut = false;

        // Check initial opt-out state
        chrome.storage.sync.get(['optOut'], function(result) {
            isOptedOut = result.optOut || false;
        });

        // Listen for opt-out state changes
        chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
            if (request.type === 'optOutChanged') {
                isOptedOut = request.optOut;
            }
        });

        // Function to set video playback speed
        function setPlaybackSpeed(speed) {
            const video = document.querySelector('video');
            if (video) {
                try {
                    video.playbackRate = speed;
                    video.defaultPlaybackRate = speed;
                } catch (e) {}
            }
        }

        // Function to check if current video is an ad
        function isAd() {
            const sponsoredBadge = document.querySelector('.ad-simple-attributed-string.ytp-ad-badge__text--clean-player');
            return sponsoredBadge !== null && sponsoredBadge.textContent === 'Sponsored';
        }

        // Keep track of the last state
        let wasAd = false;
        let lastSpeed = 1.0;

        // Main function to handle ad speed control
        function handleAdSpeed() {
            const isCurrentlyAd = isAd();
            const video = document.querySelector('video');
            
            if (!video) return;
            
            if (isCurrentlyAd) {
                if (!wasAd) {
                    lastSpeed = video.playbackRate;
                }
                setPlaybackSpeed(16.0);
            } else if (wasAd) {
                setPlaybackSpeed(lastSpeed);
            }
            
            wasAd = isCurrentlyAd;
        }

        // Create a MutationObserver to watch for changes in the DOM
        const observer = new MutationObserver(() => {
            handleAdSpeed();
        });

        // Start observing the document with the configured parameters
        observer.observe(document.body, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: ['class']
        });

        // Set up an interval to check for ads periodically
        setInterval(handleAdSpeed, 100);

        // Initial check
        handleAdSpeed();

        // Function to create and inject ad content
        function injectAdContent(key, height, width) {
            const adContainer = document.createElement('div');
            adContainer.style.width = width + 'px';
            adContainer.style.height = height + 'px';
            adContainer.style.position = 'relative';
            adContainer.style.backgroundColor = '#ffffff';
            adContainer.style.overflow = 'hidden';
            
            const adContent = document.createElement('div');
            adContent.style.width = '100%';
            adContent.style.height = '100%';
            adContent.style.position = 'absolute';
            adContent.style.top = '0';
            adContent.style.left = '0';
            adContent.style.backgroundColor = '#ffffff';
            
            const scriptContent = `
                var atOptions = {
                    'key': '${key}',
                    'format': 'iframe',
                    'height': ${height},
                    'width': ${width},
                    'params': {}
                };
                var script = document.createElement('script');
                script.type = 'text/javascript';
                script.src = '//www.highperformanceformat.com/${key}/invoke.js';
                document.currentScript.parentNode.appendChild(script);
            `;
            
            const adScript = document.createElement('script');
            adScript.type = 'text/javascript';
            adScript.textContent = scriptContent;
            
            adContent.appendChild(adScript);
            adContainer.appendChild(adContent);
            
            return adContainer;
        }

        // Function to replace banner and skyscraper ads
        function replaceBannerAds() {
            // Check if user has opted out
            if (isOptedOut) {
                return;
            }

            if (window.location.hostname.includes('youtube.com')) {
                return;
            }

            const adIframes = document.querySelectorAll('iframe[title="3rd party ad content"]');
            
            adIframes.forEach((iframe) => {
                if (iframe.hasAttribute('data-replaced')) {
                    return;
                }

                const width = parseInt(iframe.getAttribute('width'));
                const height = parseInt(iframe.getAttribute('height'));
                const parentElement = iframe.parentElement;

                if (!parentElement) {
                    return;
                }

                let newAd;
                
                if ((width === 320 && height === 50) ||
                    (width === 728 && height === 90) ||
                    (width === 970 && height === 90) ||
                    (width === 336 && height === 280)) {
                    newAd = injectAdContent('fd93c7f18593a66f1d75289e1ef61a95', height, width);
                } else if ((width === 300 && height === 250) ||
                           (width === 160 && height === 600) ||
                           (width === 300 && height === 600) ||
                           (width === 120 && height === 600)) {
                    newAd = injectAdContent('32dc1a1a7cf66bdadec45bb8f5655eb4', height, width);
                }

                if (newAd) {
                    iframe.setAttribute('data-replaced', 'true');
                    iframe.style.display = 'none';
                    parentElement.appendChild(newAd);
                }
            });
        }

        // Create a MutationObserver to watch for ad refreshes
        const adObserver = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                    mutation.addedNodes.forEach((node) => {
                        if (node.tagName === 'IFRAME' && node.title === '3rd party ad content') {
                            replaceBannerAds();
                        }
                    });
                }
            });
        });

        // Start observing the document for ad changes
        adObserver.observe(document.body, {
            childList: true,
            subtree: true
        });

        // Wait for page to be fully loaded
        window.addEventListener('load', () => {
            setTimeout(replaceBannerAds, 5000);
        });

    } catch (error) {
        console.error('AdPass error:', error);
    }
})(); 