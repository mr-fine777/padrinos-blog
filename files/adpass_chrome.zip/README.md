# YouTube Ad Speed Controller

A Firefox extension that automatically speeds up YouTube ads to 4x speed.

## Installation

1. Open Firefox and go to `about:debugging`
2. Click on "This Firefox" in the left sidebar
3. Click "Load Temporary Add-on"
4. Navigate to the extension directory and select the `manifest.json` file

## Features

- Automatically detects YouTube ads
- Speeds up ads to 4x speed
- Works on both pre-roll and mid-roll ads
- No configuration needed

## How it Works

The extension uses a MutationObserver to detect when ads are playing on YouTube and automatically sets the playback speed to 4x. This makes ads play much faster while still allowing you to see what's being advertised.

## Note

This extension only works on YouTube and requires the page to be refreshed after installation to take effect. 