document.addEventListener('DOMContentLoaded', function() {
    const checkbox = document.getElementById('optOutCheckbox');
    
    // Load the saved state
    chrome.storage.sync.get(['optOut'], function(result) {
        checkbox.checked = result.optOut || false;
    });
    
    // Save state when checkbox changes
    checkbox.addEventListener('change', function() {
        chrome.storage.sync.set({ optOut: checkbox.checked });
        
        // Notify all tabs that the state has changed
        chrome.tabs.query({}, function(tabs) {
            tabs.forEach(tab => {
                chrome.tabs.sendMessage(tab.id, {
                    type: 'optOutChanged',
                    optOut: checkbox.checked
                });
            });
        });
    });
}); 