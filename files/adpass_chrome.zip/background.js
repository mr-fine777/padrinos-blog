// Background script for YouTube Ad Speed Controller
console.log('YouTube Ad Speed Controller is running');

// Listen for installation
browser.runtime.onInstalled.addListener(() => {
    console.log('Extension installed');
}); 