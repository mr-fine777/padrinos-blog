# Installation Instructions

## Step 1: Create Icon Files

You need to convert the `icon.svg` file to PNG files for the extension to work properly.

### Option A: Online Converter
1. Go to https://convertio.co/svg-png/ or any SVG to PNG converter
2. Upload `icon.svg`
3. Convert to PNG at 96x96 pixels
4. Save as `icon96.png`
5. Convert again at 48x48 pixels
6. Save as `icon48.png`

### Option B: Using Inkscape (Free)
1. Download Inkscape from https://inkscape.org/
2. Open `icon.svg`
3. Go to File > Export PNG Image
4. Set size to 96x96, export as `icon96.png`
5. Set size to 48x48, export as `icon48.png`

### Option C: Using GIMP (Free)
1. Download GIMP from https://www.gimp.org/
2. Open `icon.svg`
3. Go to File > Export As
4. Choose PNG format
5. Set dimensions to 96x96, export as `icon96.png`
6. Repeat for 48x48 as `icon48.png`

## Step 2: Install Extension

### For Development (Temporary):
1. Open Firefox
2. Go to `about:debugging`
3. Click "This Firefox" in sidebar
4. Click "Load Temporary Add-on"
5. Select `manifest.json` from this folder

### For Permanent Installation:
1. Select all files in this folder
2. Create a ZIP archive
3. Rename the ZIP to `roblox-template-downloader.xpi`
4. Open Firefox
5. Go to `about:addons`
6. Click gear icon → "Install Add-on From File"
7. Select your `.xpi` file

## Step 3: Test the Extension

1. Go to any Roblox catalog page like:
   - https://www.roblox.com/catalog/104101119065443
   - https://www.roblox.com/catalog/7358640123
2. Click the extension icon in your toolbar
3. Click "Download Template"
4. Check your downloads folder for the PNG file

## Troubleshooting

- **Extension won't load**: Make sure all files are in the same folder
- **Icons missing**: Convert the SVG to PNG files as described above
- **Permission errors**: Make sure you're loading from a local folder, not a network drive
- **API errors**: The RobloxDEX API might be down, try again later

## File Checklist

Make sure you have these files before installing:
- [ ] manifest.json
- [ ] popup.html
- [ ] popup.js
- [ ] background.js
- [ ] content.js
- [ ] icon48.png (converted from icon.svg)
- [ ] icon96.png (converted from icon.svg)
- [ ] README.md 