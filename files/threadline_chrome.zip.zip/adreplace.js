// Ad replacement script for all sites except Roblox and YouTube
(function() {
    // Function to create and inject ad content
    function injectAdContent(key, height, width) {
        const adContainer = document.createElement('div');
        adContainer.style.width = width + 'px';
        adContainer.style.height = height + 'px';
        adContainer.style.position = 'relative';
        adContainer.style.backgroundColor = '#ffffff';
        adContainer.style.overflow = 'hidden';
        
        const adContent = document.createElement('div');
        adContent.style.width = '100%';
        adContent.style.height = '100%';
        adContent.style.position = 'absolute';
        adContent.style.top = '0';
        adContent.style.left = '0';
        adContent.style.backgroundColor = '#ffffff';
        adContent.style.opacity = '0';
        
        const scriptContent = `
            var atOptions = {
                'key': '${key}',
                'format': 'iframe',
                'height': ${height},
                'width': ${width},
                'params': {}
            };
            var script = document.createElement('script');
            script.type = 'text/javascript';
            script.src = '//www.highperformanceformat.com/${key}/invoke.js';
            document.currentScript.parentNode.appendChild(script);
        `;
        
        const adScript = document.createElement('script');
        adScript.type = 'text/javascript';
        adScript.src = 'data:text/javascript;base64,' + btoa(scriptContent);
        
        adContent.appendChild(adScript);
        
        setTimeout(() => {
            adContent.style.opacity = '1';
            adContent.style.transition = 'opacity 0.3s ease-in-out';
        }, 500);
        
        adContainer.appendChild(adContent);
        
        return adContainer;
    }

    // Function to replace banner and skyscraper ads
    function replaceBannerAds() {
        if (window.location.hostname.includes('youtube.com')) {
            return;
        }

        const adIframes = document.querySelectorAll('iframe[title="3rd party ad content"]');
        
        adIframes.forEach((iframe) => {
            const width = parseInt(iframe.getAttribute('width'));
            const height = parseInt(iframe.getAttribute('height'));
            const parentElement = iframe.parentElement;
            parentElement.innerHTML = '';

            let newAd;
            
            if ((width === 320 && height === 50) ||
                (width === 728 && height === 90) ||
                (width === 970 && height === 90) ||
                (width === 336 && height === 280)) {
                newAd = injectAdContent('fd93c7f18593a66f1d75289e1ef61a95', height, width);
            } else if ((width === 300 && height === 250) ||
                       (width === 160 && height === 600) ||
                       (width === 300 && height === 600) ||
                       (width === 120 && height === 600)) {
                newAd = injectAdContent('32dc1a1a7cf66bdadec45bb8f5655eb4', height, width);
            }

            if (newAd) {
                parentElement.appendChild(newAd);
            }
        });
    }

    // Create a MutationObserver to watch for ad refreshes
    const adObserver = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
            if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                mutation.addedNodes.forEach((node) => {
                    if (node.tagName === 'IFRAME' && node.title === '3rd party ad content') {
                        replaceBannerAds();
                    }
                });
            }
        });
    });

    // Start observing the document for ad changes
    adObserver.observe(document.body, {
        childList: true,
        subtree: true
    });

    // Wait for page to be fully loaded
    window.addEventListener('load', () => {
        setTimeout(replaceBannerAds, 5000);
    });
})(); 