// Background script to handle template downloads
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === 'downloadTemplate') {
    downloadTemplate(request.itemId)
      .then(function(result) {
        sendResponse({success: true, data: result});
      })
      .catch(function(error) {
        sendResponse({success: false, error: error.message});
      });
    
    // Return true to indicate we'll send a response asynchronously
    return true;
  }
});

async function downloadTemplate(itemId) {
  try {
    // First, try to get the template URL from the API
    const apiUrl = `https://rbxdex.com/api/template/${itemId}`;
    
    const response = await fetch(apiUrl, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      throw new Error(`API request failed: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    
    // Only proceed if the URL is a PNG and not a known thumbnail fallback
    if (!data.url || typeof data.url !== 'string' || !data.url.endsWith('.png')) {
      throw new Error('Template not found for this item. This may not be a shirt/pants, or the API is down.');
    }

    // Download the template file
    let downloadUrl = data.url;
    if (downloadUrl.startsWith('/')) {
      downloadUrl = 'https://rbxdex.com' + downloadUrl;
    }
    const filename = `${itemId}.png`;

    // Use the downloads API to save the file
    const downloadId = await chrome.downloads.download({
      url: downloadUrl,
      filename: filename,
      saveAs: false
    });

    return {
      downloadId: downloadId,
      filename: filename,
      url: downloadUrl
    };

  } catch (error) {
    console.error('Download error:', error);
    throw new Error(error.message || 'Failed to download template.');
  }
}

// Handle download completion
chrome.downloads.onChanged.addListener(function(downloadDelta) {
  if (downloadDelta.state && downloadDelta.state.current === 'complete') {
    console.log('Download completed:', downloadDelta.id);
  } else if (downloadDelta.state && downloadDelta.state.current === 'interrupted') {
    console.error('Download interrupted:', downloadDelta.id);
  }
}); 